Portfolio Platform using Node.js
Description
A robust portfolio platform developed using Node.js, MongoDB, and Express.js. It enables user authentication and role-based access control while supporting portfolio item management with API integration. This project demonstrates secure coding practices, including password hashing and Two-Factor Authentication (2FA), and integrates real-time space-related images and news.

Features
1. Authentication and Authorization
User registration with:
Fields: username, password, first name, last name, age, gender, and role.
Two-Factor Authentication (2FA) setup using an authenticator app (e.g., Google Authenticator).
Passwords securely hashed using bcrypt.
Role-based access:
Admin: Full control to manage content.
Editor: Can create but cannot edit or delete.
Login flow includes 2FA code validation (if enabled).
Session management with cookies.
2. Portfolio Management (CRUD Operations)
Users can create, read, update, and delete portfolio items.
Each portfolio item includes:
A title and description.
Three images displayed in a carousel.
Timestamps for creation and updates.
Restricted editing and deletion rights based on user roles.
3. API Integration
NASA API: Fetches random space images.
News API: Displays the latest space-related news.
4. Email Notifications
Sends a welcome email upon successful registration.
Sends notifications for key events, such as failed login attempts.
5. Responsive Design
Designed with EJS templates and CSS for a clean, user-friendly interface.
Fully responsive for mobile and desktop use.
Setup Instructions
Prerequisites
Node.js: v14 or higher
MongoDB: Local or cloud instance
npm: v6 or higher
Steps
Clone the Repository:
bash
Копировать код
git clone https://github.com/your_username/portfolio-platform.git
Navigate to the Project Directory:
bash
Копировать код
cd portfolio-platform
Install Dependencies:
bash
Копировать код
npm install
Set Up Environment Variables:
Create a .env file in the root directory.
Add the following:
env
Копировать код
MONGO_URI=your_mongodb_connection_string
NASA_API_KEY=kn1O1gA8aQHNFeoCo52icJCEtXGDgtdbr1QCyVxf
NEWS_API_KEY=188efcd9eaf247458d20841a7bc41228
EMAIL_USER=mreydm@gmail.com
EMAIL_PASS=1234
Start the Server:
bash
Копировать код
npm start
Open in Browser:
Navigate to http://localhost:3000.
API Details
1. NASA API:
Endpoint: https://api.nasa.gov/planetary/apod
Purpose: Provides random space-related images.
Key Parameter: api_key (your NASA API key).
Example Request:
bash
Копировать код
https://api.nasa.gov/planetary/apod?api_key=kn1O1gA8aQHNFeoCo52icJCEtXGDgtdbr1QCyVxf
Documentation: NASA API Docs
2. News API:
Endpoint: https://newsapi.org/v2/everything
Purpose: Fetches the latest news about space.
Key Parameter: apiKey (your News API key).
Example Request:
bash
Копировать код
https://newsapi.org/v2/everything?q=space&apiKey=188efcd9eaf247458d20841a7bc41228
Documentation: News API Docs
Design Rationale
User-Centric Interface:

Simple navigation bar for easy access to key pages.
Clear distinction between user roles to ensure streamlined functionality.
Security:

Password hashing using bcrypt ensures safe storage.
2FA adds an additional layer of security.
Responsiveness:

CSS and EJS templates provide a visually appealing and mobile-friendly design.
API Integration:

NASA API enriches the portfolio with visually engaging space images.
News API provides real-time, relevant content, adding value to the platform.
Additional Setup for 2FA
Install a TOTP Authenticator App:

Recommended: Google Authenticator or Authy.
Implementation:

Upon registration, the server generates a unique QR code using the speakeasy library.
Users scan the QR code with their authenticator app to generate 2FA codes.
During login, users must provide their 2FA code in addition to their password.
Libraries Used:

speakeasy: Generates TOTP tokens.
qrcode: Generates QR codes for easy scanning.
Example Flow:

Registration: User scans QR code during registration.
Login: User enters a valid 2FA code to gain access.

Known Issues and Limitations
Limited support for multiple languages (future enhancement planned).
2FA QR code regeneration is not yet implemented for lost codes.
Author
Alikhan Aubakirov
Group: BDA 2301

Acknowledgments
Special thanks to NASA and News API for providing valuable data.
Guidance from the WEB Technologies course instructors.
