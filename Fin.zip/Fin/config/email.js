const nodemailer = require('nodemailer');

// Настройка транспортера
const transporter = nodemailer.createTransport({
  service: 'mail.ru',
  auth: {
    user: process.env.EMAIL_USER, // ваш email
    pass: process.env.EMAIL_PASS, // пароль приложения
  },
});

// Функция для отправки писем
const sendMail = (to, subject, text) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to,
    subject,
    text,
  };

  return transporter.sendMail(mailOptions);
};

module.exports = sendMail;
