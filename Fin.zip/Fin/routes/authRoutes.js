const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');

// Регистрация
router.get('/register', (req, res) => res.render('auth/register'));
router.post('/register', authController.register);

// Вход
router.get('/login', (req, res) => res.render('auth/login'));
router.post('/login', authController.login);

// Выход
router.get('/logout', authController.logout);

module.exports = router;
