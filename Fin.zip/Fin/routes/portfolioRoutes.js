const express = require('express');
const router = express.Router();
const portfolioController = require('../controllers/portfolioController');
const { checkRole } = require('../middlewares/authMiddleware');

// Отображение всех элементов портфолио
router.get('/', portfolioController.getAllItems);

// Отображение формы создания нового элемента
router.get('/create', checkRole('editor'), portfolioController.renderCreateForm);

// Создание нового элемента
router.post('/create', checkRole('editor'), portfolioController.createItem);

// Отображение формы редактирования элемента
router.get('/edit/:id', checkRole('admin'), portfolioController.renderEditForm);

// Обновление элемента
router.post('/edit/:id', checkRole('admin'), portfolioController.updateItem);

// Удаление элемента
router.post('/delete/:id', checkRole('admin'), portfolioController.deleteItem);

module.exports = router;
