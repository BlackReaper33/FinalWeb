const PortfolioItem = require('../models/PortfolioItem');
const axios = require('axios');

// Ключи API
const NASA_API_KEY = 'kn1O1gA8aQHNFeoCo52icJCEtXGDgtdbr1QCyVxf';
const NEWS_API_KEY = '188efcd9eaf247458d20841a7bc41228';

// 1. Получение всех элементов портфолио + новости
exports.getAllItems = async (req, res) => {
  try {
    const items = await PortfolioItem.find();

    // Получение последних новостей
    const newsResponse = await axios.get(
      `https://newsapi.org/v2/everything?q=space&apiKey=${NEWS_API_KEY}`
    );
    const articles = newsResponse.data.articles;

    res.render('portfolio/index', { items, articles });
  } catch (err) {
    console.error('Ошибка загрузки портфолио или новостей:', err);
    res.status(500).send('Ошибка сервера');
  }
};

// 2. Отображение формы создания нового элемента
exports.renderCreateForm = (req, res) => {
  res.render('portfolio/create');
};

// 3. Создание нового элемента портфолио с изображением NASA
exports.createItem = async (req, res) => {
  try {
    const { title, description } = req.body;

    // Получение случайного изображения NASA
    const nasaResponse = await axios.get(
      `https://api.nasa.gov/planetary/apod?api_key=${NASA_API_KEY}`
    );
    const randomPhoto = nasaResponse.data.url;

    const newItem = new PortfolioItem({
      title,
      description,
      images: [randomPhoto], // Добавляем изображение NASA
    });

    await newItem.save();
    res.redirect('/portfolio');
  } catch (err) {
    console.error('Ошибка при создании элемента портфолио:', err);
    res.status(500).send('Ошибка сервера при создании элемента');
  }
};

// 4. Отображение формы редактирования элемента
exports.renderEditForm = async (req, res) => {
  try {
    const item = await PortfolioItem.findById(req.params.id);
    res.render('portfolio/edit', { item });
  } catch (err) {
    res.status(404).send('Элемент не найден');
  }
};

// 5. Обновление элемента портфолио
exports.updateItem = async (req, res) => {
  try {
    const { title, description } = req.body;
    await PortfolioItem.findByIdAndUpdate(req.params.id, {
      title,
      description,
      updatedAt: Date.now(),
    });
    res.redirect('/portfolio');
  } catch (err) {
    console.error('Ошибка при обновлении элемента портфолио:', err);
    res.status(500).send('Ошибка сервера при обновлении');
  }
};

// 6. Удаление элемента портфолио
exports.deleteItem = async (req, res) => {
  try {
    await PortfolioItem.findByIdAndDelete(req.params.id);
    res.redirect('/portfolio');
  } catch (err) {
    console.error('Ошибка при удалении элемента портфолио:', err);
    res.status(500).send('Ошибка сервера при удалении');
  }
};
