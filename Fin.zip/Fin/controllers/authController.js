const User = require('../models/User');
const bcrypt = require('bcrypt');
const sendMail = require('../config/email'); // Убедитесь, что путь верный

// Вход пользователя
exports.login = async (req, res) => {
  try {
    const { username, password } = req.body;

    console.log('Введённый username:', username);
    console.log('Введённый password:', password);

    // Ищем пользователя в базе данных
    const user = await User.findOne({ username });
    if (!user) {
      console.error(`Пользователь с именем ${username} не найден.`);
      return res.status(400).send('Неверные учетные данные');
    }

    console.log('Пользователь найден:', user);

    // Временно пропускаем проверку пароля
    console.log('Пароль проверка пропущена, пользователь вошел автоматически.');

    // Сохраняем данные пользователя в сессии
    req.session.user = {
      id: user._id,
      username: user.username,
      role: user.role,
    };

    console.log('Пользователь успешно вошел:', req.session.user);

    res.redirect('/portfolio'); // Перенаправляем пользователя на главную страницу
  } catch (err) {
    console.error('Ошибка сервера при входе:', err);
    res.status(500).send('Ошибка сервера при входе');
  }
};

// Регистрация пользователя
exports.register = async (req, res) => {
  try {
    const { username, password, firstName, lastName, age, gender, role } = req.body;

    // Проверяем, существует ли пользователь
    const existingUser = await User.findOne({ username });
    if (existingUser) {
      console.error('Попытка зарегистрировать существующего пользователя:', username);
      return res.status(400).send('Пользователь с таким именем уже существует');
    }

    // Хэшируем пароль (это останется, чтобы пароли всё равно сохранялись хэшированными)
    const hashedPassword = await bcrypt.hash(password, 10);
    console.log('Хэшированный пароль:', hashedPassword);

    // Создаем нового пользователя
    const user = new User({
      username,
      password: hashedPassword, // Сохраняем хэшированный пароль
      firstName,
      lastName,
      age,
      gender,
      role: role || 'editor', // Если роль не указана, по умолчанию "editor"
    });

    await user.save();

    await sendMail(
      username,
      'Добро пожаловать в Portfolio App!',
      `Здравствуйте, ${firstName}! Вы успешно зарегистрировались в нашем приложении.`
    );

    console.log('Пользователь успешно зарегистрирован:', user);

    res.redirect('/auth/login');
  } catch (err) {
    console.error('Ошибка сервера при регистрации:', err);
    res.status(500).send('Ошибка сервера при регистрации');
  }
};

// Выход пользователя
exports.logout = (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error('Ошибка при выходе из системы:', err);
      return res.status(500).send('Ошибка при выходе из системы');
    }
    console.log('Пользователь вышел из системы.');
    res.redirect('/auth/login');
  });
};
